#!/bin/bash
python3 core/main.py
