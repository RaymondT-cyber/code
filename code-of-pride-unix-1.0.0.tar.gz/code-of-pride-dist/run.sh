#!/bin/bash
# Run script for Code of Pride

cd "$(dirname "$0")"

echo "================================"
echo "  CODE OF PRIDE"
echo "  Marching Band Director"
echo "================================"
echo ""
echo "Starting game..."
echo ""

python3 core/main.py
